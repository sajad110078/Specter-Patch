GENX MOUNTAIN BUNKER — COMPLETE INTEGRATION PACK
================================================
Target: Command & Conquer Generals / Zero Hour (W3D 3.0)

1) W3D: Art/W3D/GENX_BUNKER.w3d contains high + low render meshes, root
   hierarchy, a legacy Generals LODModel, and a hidden physical collision mesh.
2) Textures: 1024x1024 atlas with rock, concrete, asphalt and dark metal tiles.
3) LOD: Generals-era W3D 3.0 uses HMODEL (0x300) and LODMODEL (0x400).
   This pack uses those legacy chunks rather than a later 0x700 HLOD wrapper.
4) Collision: separate hidden physical collision mesh plus invisible INI
   pathing blockers for left, right and rear boundaries.
5) INI: map-placeable visual object and blocker objects, plus English strings.
6) Map placement: WorldBuilder placement guide and offsets. The real binary
   .MAP is saved by WorldBuilder after placement; no fake .MAP is included.

Validation:
- W3D chunk sizes and MeshHeader3 counts are structurally checked.
- Not yet opened in the game's W3D Viewer or tested in SPECTER FINAL.
- If the Viewer rejects the material block, import the supplied OBJ into
  RenX/GMax and export using the installed Generals W3D exporter.
- Test collision/pathing with Ctrl+I in WorldBuilder and actual tank movement.
- The interior has 30 visual parking bays. Actual vehicle enter/store/exit
  requires optional TransportContain gameplay integration; see the docs.

Install:
1. Extract the ZIP.
2. Run Tools/Install_To_Mod.ps1 -ModRoot "PATH_TO_MOD".
3. Add GENX_MountainBunker.ini to the mod's INI load/include order.
4. Follow Map/WorldBuilder_Placement_Guide.txt.
5. Run python Tools/Verify_W3D.py Art/W3D/GENX_BUNKER.w3d.
