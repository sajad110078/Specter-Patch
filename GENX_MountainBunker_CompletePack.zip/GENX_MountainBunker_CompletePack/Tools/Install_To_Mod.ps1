param([Parameter(Mandatory=$true)][string]$ModRoot)
$ErrorActionPreference = "Stop"
# The script is stored in <pack>\Tools; resolve the pack root one level up.
$PackRoot = Resolve-Path (Join-Path $PSScriptRoot "..")
$files = @{
  "Art/W3D/GENX_BUNKER.w3d" = "Data/Art/W3D/GENX_BUNKER.w3d"
  "Art/Textures/GENX_Bunker_Atlas.tga" = "Data/Art/Textures/GENX_Bunker_Atlas.tga"
  "INI/Object/GENX_MountainBunker.ini" = "Data/INI/Object/GENX_MountainBunker.ini"
  "INI/English/GENX_MountainBunker.str" = "Data/English/GENX_MountainBunker.str"
}
foreach ($src in $files.Keys) {
  $from = Join-Path $PackRoot $src
  $to = Join-Path $ModRoot $files[$src]
  New-Item -ItemType Directory -Force -Path (Split-Path $to) | Out-Null
  Copy-Item -Force $from $to
  Write-Host "Copied $src -> $($files[$src])"
}
Write-Host ""
Write-Host "Add GENX_MountainBunker.ini to the mod's INI load/include order."
Write-Host "Then follow Map/WorldBuilder_Placement_Guide.txt."
