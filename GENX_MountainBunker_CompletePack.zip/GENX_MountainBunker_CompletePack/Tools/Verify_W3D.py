from pathlib import Path
import struct, sys
path=Path(sys.argv[1] if len(sys.argv)>1 else "Art/W3D/GENX_BUNKER.w3d")
data=path.read_bytes()
def chunks(blob,label):
    out=[]; off=0
    while off<len(blob):
        if off+8>len(blob): raise ValueError(f"{label}: truncated header")
        cid,size=struct.unpack_from("<II",blob,off); n=size&0x7fffffff
        end=off+8+n
        if end>len(blob): raise ValueError(f"{label}: chunk {cid:#x} exceeds file")
        out.append((cid,bool(size&0x80000000),blob[off+8:end])); off=end
    return out
top=chunks(data,"top")
print("Top-level chunks:",[hex(x[0]) for x in top])
for cid,nested,payload in top:
    if cid==0:
        sub=chunks(payload,"mesh")
        h=[x[2] for x in sub if x[0]==0x1f][0]
        ver,flags=struct.unpack_from("<II",h,0)
        ntri,nvert,nmat=struct.unpack_from("<3I",h,40)
        print("mesh version",hex(ver),"flags",hex(flags),"triangles",ntri,"vertices",nvert,"materials",nmat)
        assert ver==0x30000 and ntri>0 and nvert==ntri*3
print("Chunk bounds and mesh headers: PASS")
